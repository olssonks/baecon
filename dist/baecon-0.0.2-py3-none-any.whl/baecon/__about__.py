# SPDX-FileCopyrightText: 2023-present Kevin Olsson <olssonks@gmail.com>
#
# SPDX-License-Identifier: FNU GPLv3
__version__ = "0.0.2"
