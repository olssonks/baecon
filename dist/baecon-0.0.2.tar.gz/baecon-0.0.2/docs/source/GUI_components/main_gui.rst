Main GUI
========

.. autofunction:: baecon.GUI.baecon_GUI.main

.. automodule:: baecon.GUI.gui_utils
    :members:
    :exclude-members: dataclass, field, Path, Optional, ui, bc
    
.. autoclass:: baecon.GUI.gui_utils.load_file
    :members:
    :undoc-members:
    :private-members: _handle_ok