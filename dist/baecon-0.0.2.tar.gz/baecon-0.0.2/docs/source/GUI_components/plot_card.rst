Plot Card
=========

.. automodule:: baecon.GUI.cards.plot_card
    :members: