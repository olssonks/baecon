Scan Card
=========

.. automodule:: baecon.GUI.cards.scan_card
    :members: