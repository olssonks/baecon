Data Card
=========

.. automodule:: baecon.GUI.cards.data_card
    :members: