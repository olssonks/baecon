Engine
======

.. automodule:: baecon.engine
    :imported-members:
    :members:
    :exclude-members: dataclass, numpy, queue, threading, copy