Devices
=======

This is the list of the currently available devices:
