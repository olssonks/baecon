Devices Card
============

.. automodule:: baecon.GUI.cards.devices_card
    :members: