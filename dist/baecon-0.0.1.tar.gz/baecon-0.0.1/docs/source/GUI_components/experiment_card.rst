Experiment Card
===============

.. automodule:: baecon.GUI.cards.experiment_card
    :members: