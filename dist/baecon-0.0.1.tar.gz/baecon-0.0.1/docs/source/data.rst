Data
====

.. automodule:: baecon.data
    :imported-members:
    :members:
    :exclude-members: dataclass, field, numpy, xarray
    