Device
======

.. autoclass:: baecon.device.Device
    :members:

    .. automethod:: __init__


