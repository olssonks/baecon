Base
====

.. automodule:: baecon.base
    :imported-members:
    :members:
    :exclude-members: dataclass, field, Device, numpy
    
