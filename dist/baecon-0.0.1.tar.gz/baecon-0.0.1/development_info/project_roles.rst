+++++++++++++
Project Roles
+++++++++++++
To be determined

Project Manager
================
* Organize project plan
* Assign tasks
* Manage schedule and timeline
* Determine/review methodology

Operational Manager
===================
* Create best practices
* Develop/help with automating workflow
* Maintain code and repo
* Maintain documentation

Testing Manager
===============
* Developing unit tests
* Help contributers with unit tests
* Run test for merging into central branches

Contributers
============
* Develop new devices, engines, etc.
* Add to documentation
* Create demos